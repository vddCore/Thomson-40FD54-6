/* $OpenBSD: version.h,v 1.74 2015/08/02 09:56:42 djm Exp $ */

#define SSH_VERSION	"OpenSSH_7.0"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
